import React, { useEffect, useMemo, useState } from 'react'
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'
export default function App(){
  const [tab,setTab]=useState('feed'); const [search,setSearch]=useState(''); const [profiles,setProfiles]=useState([])
  const [groups,setGroups]=useState([]); const [messages,setMessages]=useState([]); const [groupName,setGroupName]=useState('')
  const [newMessage,setNewMessage]=useState(''); const [polls,setPolls]=useState({}); const [selected,setSelected]=useState(null)
  useEffect(()=>{ fetch(`${API_BASE}/api/investors`).then(r=>r.json()).then(setProfiles).catch(()=>{}); fetch(`${API_BASE}/api/groups`).then(r=>r.json()).then(setGroups).catch(()=>{}) },[])
  const visible=useMemo(()=>{ if(!search) return profiles; const q=search.toLowerCase(); return profiles.filter(p=>p.name.toLowerCase().includes(q)||(p.category||'').toLowerCase().includes(q)|| (p.investments||[]).join(' ').toLowerCase().includes(q)) },[profiles,search])
  const createGroup=async()=>{ if(!groupName.trim())return; const r=await fetch(`${API_BASE}/api/groups`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:groupName})}); const g=await r.json(); setGroups(x=>[...x,g]); setGroupName('') }
  const sendMessage=()=>{ if(!newMessage.trim())return; setMessages(m=>[...m,{id:m.length+1,text:newMessage}]); setNewMessage('') }
  return (<div className='min-h-screen bg-white text-gray-900'>
    <header className='sticky top-0 z-20 bg-white/90 backdrop-blur border-b p-3 flex items-center justify-between'>
      <div className='flex items-center gap-3'><div className='text-2xl font-bold'>Silicon Showdown</div>
      <input className='w-72 px-3 py-2 rounded-xl border' placeholder='Search investors or assets' value={search} onChange={e=>setSearch(e.target.value)} /></div>
      <nav className='flex items-center gap-2'>
        {['feed','dashboard','news','charts','groups'].map(t=><button key={t} onClick={()=>setTab(t)} className={`px-3 py-1 rounded ${tab===t?'bg-gray-100':''}`}>{t[0].toUpperCase()+t.slice(1)}</button>)}
        <a href='https://www.gofundme.com/' target='_blank' rel='noreferrer' className='ml-2'><button className='px-3 py-2 rounded-xl border bg-black text-white'>Donate</button></a>
      </nav>
    </header>
    <main className='p-4'>
      {tab==='feed' && <section><div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4'>
        {visible.slice(0,36).map(inv=>(<div key={inv.id} className='border rounded-2xl overflow-hidden bg-white shadow-sm'>
          <div className='h-52 relative bg-gray-100'>{inv.imageUrl? <img src={inv.imageUrl} alt={inv.name} className='w-full h-full object-cover'/> : <div className='w-full h-full bg-gray-200'/>}
            <div className='absolute bottom-0 inset-x-0 bg-black/50 text-white p-3'><div className='font-semibold'>{inv.name}</div>
              <div className='text-xs opacity-90'>{inv.category} • Net worth: <span className='font-semibold'>{inv.netWorth}</span></div></div></div>
          <div className='p-3 space-y-2'><div className='text-sm text-gray-700'>Top investments: <span className='font-medium'>{(inv.investments||[]).join(', ')}</span></div>
            <div className='flex gap-2'><button className='px-3 py-2 rounded-xl border flex-1' onClick={()=>setSelected(inv)}>View</button><button className='px-3 py-2 rounded-xl border bg-black text-white flex-1'>Follow</button></div>
          </div></div>))}</div></section>}
      {tab==='groups' && <section className='grid grid-cols-1 lg:grid-cols-3 gap-4'>
        <div className='lg:col-span-2 border rounded-2xl p-4'><h4 className='font-bold mb-2'>Create a Group</h4>
          <div className='flex gap-2'><input className='px-3 py-2 border rounded-xl w-full' placeholder='Group name' value={groupName} onChange={e=>setGroupName(e.target.value)}/>
            <button className='px-3 py-2 rounded-xl border bg-black text-white' onClick={createGroup}>Create</button></div>
          <div className='mt-4'>{groups.length===0 && <div className='text-sm text-gray-500'>No groups yet — be the first to create one.</div>}
            {groups.map(g=>(<div key={g.id} className='p-3 border rounded mb-2 flex justify-between items-center'><div>{g.name}</div><button className='px-3 py-2 rounded-xl border'>Join</button></div>))}</div>
          <div className='mt-4'><h4 className='font-bold mb-2'>Group Chat</h4>
            <div className='border rounded p-3 h-56 overflow-y-auto bg-gray-50'>{messages.map(m=><div key={m.id} className='mb-2 p-2 bg-white rounded shadow-sm'>{m.text}</div>)}</div>
            <div className='flex gap-2 mt-3'><textarea className='px-3 py-2 border rounded-xl w-full' value={newMessage} onChange={e=>setNewMessage(e.target.value)} placeholder='Write a message...'/>
              <button className='px-3 py-2 rounded-xl border bg-black text-white' onClick={sendMessage}>Send</button></div></div></div>
        <aside className='border rounded-2xl p-4'><h4 className='font-bold mb-2'>Top Profiles</h4>
          <ol className='list-decimal pl-5 text-sm'>{profiles.slice(0,10).map(inv=>(<li key={inv.id} className='mb-2'>{inv.name} — <span className='font-semibold'>{inv.netWorth}</span></li>))}</ol></aside>
      </section>}
    </main>
    {selected && (<div className='fixed inset-0 z-30 bg-black/50 flex items-center justify-center p-4' onClick={()=>setSelected(null)}>
      <div className='bg-white rounded-2xl max-w-2xl w-full overflow-hidden' onClick={e=>e.stopPropagation()}>
        <div className='h-56 bg-gray-100 relative'>{selected.imageUrl? <img src={selected.imageUrl} alt={selected.name} className='w-full h-full object-cover'/> : <div className='w-full h-full bg-gray-200'/>}
          <button className='absolute top-3 right-3 bg-white/80 rounded-full px-3 py-1' onClick={()=>setSelected(null)}>✕</button></div>
        <div className='p-4 space-y-2'><div className='text-2xl font-bold'>{selected.name}</div>
          <div className='text-sm text-gray-600'>{selected.category} • Net worth: <span className='font-semibold'>{selected.netWorth}</span></div>
          <div className='text-sm'>Top investments: {(selected.investments||[]).join(', ')}</div>
          <div className='pt-2 flex gap-2'><button className='px-3 py-2 rounded-xl border bg-black text-white flex-1'>Follow</button>
            <a href='https://www.gofundme.com/' target='_blank' rel='noreferrer' className='flex-1'><button className='px-3 py-2 rounded-xl border w-full'>Donate</button></a></div></div></div></div>)}
  </div>)
}
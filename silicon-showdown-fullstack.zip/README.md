# Silicon Showdown — Fullstack
- client/: React + Vite + Tailwind
- server/: Node + Express

## Local dev
# server
cd server && npm install && npm run dev
# client (in another terminal)
cd client && npm install && npm run dev

Set VITE_API_BASE in client/.env to your deployed API when you deploy the backend.

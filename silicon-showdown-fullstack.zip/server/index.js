import express from 'express'
import cors from 'cors'
const app = express(); app.use(cors()); app.use(express.json())
const PORT = process.env.PORT || 4000
const investors=[
 { id:1,name:'Elon Musk',category:'Billionaire – Tech',investments:['Tesla','SpaceX','X (Twitter)'],netWorth:'est. $300B+',imageUrl:'https://upload.wikimedia.org/wikipedia/commons/3/34/Elon_Musk_Royal_Society_%28crop1%29.jpg' },
 { id:2,name:'Jeff Bezos',category:'Billionaire – Retail/Space',investments:['Amazon','Blue Origin'],netWorth:'est. $200B+',imageUrl:'https://upload.wikimedia.org/wikipedia/commons/4/4f/Jeff_Bezos%27_iconic_image_from_2019.jpg' },
 { id:3,name:'Mark Zuckerberg',category:'Billionaire – Tech',investments:['Meta (Facebook, Instagram)'],netWorth:'est. $200B+',imageUrl:'https://upload.wikimedia.org/wikipedia/commons/5/5c/Mark_Zuckerberg_F8_2019_Keynote_%2847909937812%29_%28cropped%29.jpg' },
 { id:4,name:'BlackRock',category:'Asset Manager',investments:['iShares ETFs'],netWorth:'AUM: $9T+',imageUrl:'https://upload.wikimedia.org/wikipedia/commons/8/8d/BlackRock_wordmark.svg' },
 { id:5,name:'Vanguard',category:'Asset Manager',investments:['Index Funds','ETFs'],netWorth:'AUM: $7T+',imageUrl:'https://upload.wikimedia.org/wikipedia/commons/6/6d/Vanguard_Logo.svg' }
]
let groups=[{id:1,name:'AI & Crypto'}]
app.get('/api/health',(req,res)=>res.json({ok:true}))
app.get('/api/investors',(req,res)=>res.json(investors))
app.get('/api/groups',(req,res)=>res.json(groups))
app.post('/api/groups',(req,res)=>{const {name}=req.body||{}; const g={id:groups.length+1,name:String(name||'New Group').slice(0,64)}; groups.push(g); res.json(g)})
app.get('/api/news',(req,res)=>{res.json([{id:1,title:'Forbes Rich List update — rankings shift after market move'},{id:2,title:'Bloomberg: Mega-cap AI stocks lead indices higher'},{id:3,title:'CoinDesk: ETH upgrade timeline and staking flows'}])})
app.listen(PORT,()=>console.log('Silicon Showdown API running on :'+PORT))